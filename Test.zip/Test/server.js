const express = require('express')
const uuid = require('uuid').v4
const multer = require('multer');
const app = express();
const fse = require('fs')
const console = require('console')
app.use(express.json());
const storage = multer.diskStorage({
    destination: './uploadFiles/',
    filename(req, file, cb) {
        console.log(file)
        const newFileName = `${Date.now()}-${file.originalname}`
        cb(null, newFileName);
    }
})
const uploadVideoFile = multer({
    storage: storage
}).single("videoFile");
app.post('/upload', uploadVideoFile, (req, res) => {
    console.log(req.body)
    console.log(req.file)
    try {
        if (req.file) {
            const file = req.file.path;
            const { title, description } = req.body;
        } else {
            console.log("error")
        }
        res.json({
            'title':req.body.title,
            'description':req.body.description,
            'image': req.file.path
        })
    } catch (error) {
        
    }  
})
const PORT = 8000;
app.listen(PORT, (req, res) => {
    console.log("app is live")
}
)